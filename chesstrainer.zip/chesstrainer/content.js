// Get the div element with class "nav-menu-area"
const navMenuArea = document.querySelector('.nav-menu-area');
var hisColor;
var bgColor="#ff000033";
// Create a button element
const button = document.createElement('button');
button.setAttribute("id", "starter");
button.setAttribute("style", "width:80%;margin-left:10px");;
button.textContent = 'Activate trainer';
const p= document.createElement("br");
const textInput= document.createElement("input");
textInput.setAttribute("placeholder", "0-80");
textInput.setAttribute("id", "opacity");
textInput.setAttribute("style", "width:40px;margin-left:10px;");
const ok= document.createElement("button");
ok.setAttribute("id", "ok");
ok.setAttribute("style", "width:40px;margin-left:10px;margin-bottom:10px;");
ok.textContent="Set";
// Add the button to the div element
navMenuArea.appendChild(button);
navMenuArea.appendChild(p);

navMenuArea.appendChild(textInput);
navMenuArea.appendChild(ok);
// navMenuArea.appendChild("input type='text' placeholder='0-80'");
// navMenuArea.append("<input type='button' id='ok'>");

// Add a click event listener to the button
button.addEventListener('click', () => {
//   // Prompt the user to click Ok or Cancel and store the result in a variable
  const result = confirm('What color are you playing? Click Ok for white and Cancel for black');
//
//   // Assign the value of the variable "choice" based on the user's choice
  const choice = result ? true : false;
//
  if(choice){hisColor="b";}else{hisColor="w";} // if "Ok" was selected, the color to be worked on is black, and vice versa.
  // paint();
  console.log(hisColor);
  document.getElementById("board-play-computer").style.backgroundImage="url('https://images.chesscomfiles.com/chess-themes/boards/newspaper/200.png')";
  foo();

});



ok.addEventListener('click', () => {  /// this is what gets called when "Set" button is clicked.

var enteredColor=document.getElementById("opacity").value;    // it gets the inserted value from the text input field


if(enteredColor.toString().length<=2 && parseInt(enteredColor)>=0 && parseInt(enteredColor)<=80){  /// range of accepted inputs

enteredColor=parseInt(enteredColor*2.56);
enteredColor=enteredColor.toString(16);    //// convert to hexadecimal
var zero = 0;
if(enteredColor.length<2){enteredColor=zero.toString()+enteredColor.toString();}     /// to ensure the new opacity value has 2 digits in the hexadecimal form

bgColor=bgColor.toString().substring(0,7) + enteredColor.toString();
limpa();run();

}
}

)


function checkTile(x,y){
  try{  // this is to prevent tiles of the "highlight" class to cause issues
    inspect=document.querySelectorAll(".square-"+x.toString()+y.toString())[0].className;
    if(inspect.search("highlight")!=-1){var a=1;} // when there's a tile that's occupied and also have a highlight class
    else{var a=0;}
  }
  catch{ return 0;}


  try{
  inspect=document.querySelectorAll(".square-"+x.toString()+y.toString())[a].className; // here the code wants to check if the tile is empty, or occupied
  if(inspect.indexOf("artificial")!=-1){return 0;} /// tiles of the class artificial is something i came up with so it's possible to paint empty tiles
  return 1;
}
  catch{  // this is what happens when the tile is empty (in case it doesn't belong to artificial class)
    return 0;

  }

}



function paintTile(x,y){   /// function that decides if the tile (x,y) gets painted or not
  if(x<1 || x>8 || y<1 || y>8){return null;}
  else{
    try{
     document.getElementsByClassName("square-"+x.toString()+y.toString())[0].style.backgroundColor=bgColor;
    }
    catch{  
      var innerDiv=document.createElement("div");
      innerDiv.className="piece artificial square-"+x.toString()+y.toString();
      innerDiv.innerHTML=""
      innerDiv.style.cssText = "background-color:"+bgColor;
      try{
      document.getElementById("board-play-computer").append(innerDiv);
    }
    catch{
      // document.getElementById("board-vs-personalities").append(innerDiv);
      document.getElementById("board-single").append(innerDiv);

    }
    }

  }

  return null;
}


function removeElementsByClass(){
  // elements[0].style.removeProperty('background-color');
  for (i=1;i<9;i++){
    for (j=1;j<9;j++){
      try{
        var elements=document.getElementsByClassName("square-"+i.toString()+j.toString());
        for (k=0;k<elements.length;k++){
        elements[k].style.removeProperty("background-color");
      }
      }
      catch{}
          }
        }

    var tiles = document.getElementsByClassName("artificial");
    while(tiles.length > 0){
      tiles[0].parentNode.removeChild(tiles[0]);
    }

  }


function limpa(){  //// unpaints everything
  try{document.getElementsByClassName("highlight")[0].remove();}catch{}
  try{document.getElementsByClassName("highlight")[1].remove();}catch{}
  try{document.getElementsByClassName("hover-square")[0].style.visibility="visible";}catch{}
  try{document.getElementsByClassName("hover-square")[0].remove();}catch{}
}


function foo() {

    run()


    setTimeout(foo, 500);
}

foo();


function run(){

removeElementsByClass(); // erase all the red tiles, in order to paint them again on updated positions

limpa();  // function that removes "style:hidden" and "opacity:0.5", which chess.com eventually adds to some times

////////////// BISHOP

var bishopIndex=[[[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7],[8,8]],[[1,-1],[2,-2],[3,-3],[4,-4],[5,-5],[6,-6],[7,-7],[8,-8]],
[[-1,1],[-2,2],[-3,3],[-4,4],[-5,5],[-6,6],[-7,7],[-8,8]],[[-1,-1],[-2,-2],[-3,-3],[-4,-4],[-5,-5],[-6,-6],[-7,-7],[-8,-8]]];

for (i=0;i<document.querySelectorAll("."+hisColor+"b").length;i++) // for each of opponent's bishops
{
var x=0;
var y=0;
var html = document.querySelectorAll("."+hisColor+"b")[i].className;
// console.log(html);
html=html.substring(html.indexOf("square"));
x=html.substring(7,8);
y=html.substring(8,9); // bishops' coordinates



for (j=0;j<bishopIndex.length;j++){  // for each diagonal (+x,+y),(+x,-y),(-x,+y),(-x,-y)
  for (k=0;k<bishopIndex[j].length;k++){
    x=parseInt(x);y=parseInt(y);
    var a=parseInt(bishopIndex[j][k][0]);
    var b=parseInt(bishopIndex[j][k][1]);
    if (checkTile((x+a).toString(),(y+b).toString())==1){
      paintTile((x+a).toString(),(y+b).toString());break;
    }
    else{
      paintTile((x+a).toString(),(y+b).toString());
    }


}

}
}

//////////// END OF BISHOP

//////////// KNIGHT

var knightIndex=[[1,2],[2,1],[-1,2],[-2,1],[-1,-2],[-2,-1],[1,-2],[2,-1]];

for (i=0;i<document.querySelectorAll("."+hisColor+"n").length;i++) // for each opponent's knight
{
var x=0;
var y=0;
var html = document.querySelectorAll("."+hisColor+"n")[i].className;
html=html.substring(html.indexOf("square"));
x=html.substring(7,8);
y=html.substring(8,9); // knight's coordinates


for (j=0;j<knightIndex.length;j++){
  x=parseInt(x);y=parseInt(y);
  var a=parseInt(knightIndex[j][0]);
  var b=parseInt(knightIndex[j][1]);
  paintTile((x+a).toString(),(y+b).toString());

}
}

/////////// END OF KNIGHT

/////////// ROOK

var rookIndex=[[[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[7,0],[8,0]],[[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[0,8]],
[[0,-1],[0,-2],[0,-3],[0,-4],[0,-5],[0,-6],[0,-7],[0,-8]],[[-1,0],[-2,0],[-3,0],[-4,0],[-5,0],[-6,0],[-7,0],[-8,0]]];

for (i=0;i<document.querySelectorAll("."+hisColor+"r").length;i++) // loop executed for each of opponent's rooks
{
var x=0;
var y=0;
var html = document.querySelectorAll("."+hisColor+"r")[i].className;
// console.log(html);
html=html.substring(html.indexOf("square"));
x=html.substring(7,8);
y=html.substring(8,9); // rook's coordinates


// console.log("-----------------------------------------")
for (j=0;j<rookIndex.length;j++){  // for each of the 4 directions (+x,+0)(+0,-y),(-x,0),(0,-y)
  // console.log("------------------")
  for (k=0;k<rookIndex[j].length;k++){
    x=parseInt(x);y=parseInt(y);
    var a=parseInt(rookIndex[j][k][0]);
    var b=parseInt(rookIndex[j][k][1]);
    // console.log("x: " + x.toString() + ", y: " + y.toString() + ", x+a: " + (parseInt(x)+parseInt(a)).toString() + ", y+b: " + (parseInt(y)+parseInt(b)).toString().toString());
    if (checkTile((x+a).toString(),(y+b).toString())==1){
      paintTile((x+a).toString(),(y+b).toString());break;
    }
    else{
      paintTile((x+a).toString(),(y+b).toString());
    }
}
}
}

////// END OF ROOK


////// QUEEN

var queenIndex=[[[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[7,0],[8,0]],[[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[0,8]],
[[0,-1],[0,-2],[0,-3],[0,-4],[0,-5],[0,-6],[0,-7],[0,-8]],[[-1,0],[-2,0],[-3,0],[-4,0],[-5,0],[-6,0],[-7,0],[-8,0]],
[[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7],[8,8]],[[1,-1],[2,-2],[3,-3],[4,-4],[5,-5],[6,-6],[7,-7],[8,-8]],
[[-1,1],[-2,2],[-3,3],[-4,4],[-5,5],[-6,6],[-7,7],[-8,8]],[[-1,-1],[-2,-2],[-3,-3],[-4,-4],[-5,-5],[-6,-6],[-7,-7],[-8,-8]]];


for (i=0;i<document.querySelectorAll("."+hisColor+"q").length;i++) 
{
var x=0;
var y=0;
var html = document.querySelectorAll("."+hisColor+"q")[i].className;
html=html.substring(html.indexOf("square"));
x=html.substring(7,8);
y=html.substring(8,9); 



for (j=0;j<queenIndex.length;j++){  // for each direction (+x,+0)(+0,-y),(-x,0),(0,-y),(+x,+x),(+x,-y),etc...
  for (k=0;k<queenIndex[j].length;k++){
    x=parseInt(x);y=parseInt(y);
    var a=parseInt(queenIndex[j][k][0]);
    var b=parseInt(queenIndex[j][k][1]);
    if (checkTile((x+a).toString(),(y+b).toString())==1){
      paintTile((x+a).toString(),(y+b).toString());break;
    }
    else{
      paintTile((x+a).toString(),(y+b).toString());
    }
}
}
}

////// END OF QUEEN

////// KING

var kingIndex=[[1,1],[0,1],[-1,1],[1,0],[1,-1],[0,-1],[-1,0],[-1,-1]];

for (i=0;i<document.querySelectorAll("."+hisColor+"k").length;i++)
{
var x=0;
var y=0;
var html = document.querySelectorAll("."+hisColor+"k")[i].className;
html=html.substring(html.indexOf("square"));
x=html.substring(7,8);
y=html.substring(8,9); // king's coordinates


for (j=0;j<kingIndex.length;j++){
  x=parseInt(x);y=parseInt(y);
  var a=parseInt(kingIndex[j][0]);
  var b=parseInt(kingIndex[j][1]);
  paintTile((x+a).toString(),(y+b).toString());

}
}

///// END OF KING


////// PAWNS

for (i=0;i<document.querySelectorAll("."+hisColor+"p").length;i++)
{
var x=0;
var y=0;
var html = document.querySelectorAll("."+hisColor+"p")[i].className;
// console.log(html);
html=html.substring(html.indexOf("square"));
x=html.substring(7,8);
y=html.substring(8,9); // coordinates of each pawn
x=parseInt(x);y=parseInt(y);
if (hisColor=="b"){
paintTile((x+1).toString(),(y-1).toString());
paintTile((x-1).toString(),(y-1).toString());
}
else{
paintTile((x+1).toString(),(y+1).toString());
paintTile((x-1).toString(),(y+1).toString());

}


}

////// END OF PAWN



// limpa();
} // end of run
